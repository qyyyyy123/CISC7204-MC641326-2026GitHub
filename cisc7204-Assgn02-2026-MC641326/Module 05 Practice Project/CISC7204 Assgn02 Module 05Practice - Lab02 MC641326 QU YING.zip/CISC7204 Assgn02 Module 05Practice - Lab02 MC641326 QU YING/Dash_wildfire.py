import pandas as pd
import dash
from dash import html, dcc
from dash.dependencies import Input, Output
import plotly.express as px
import warnings

# Ignore warnings for a cleaner terminal
warnings.filterwarnings('ignore')

# Create app
app = dash.Dash(__name__)

# Clear the layout and do not display exception till callback gets executed
app.config.suppress_callback_exceptions = True

# --- DATA LOADING SECTION ---
try:
    # Try reading from local file first (since URL might be broken)
    df = pd.read_csv('Historical_wildfires.csv')
    print("Loaded data from local file.")
except FileNotFoundError:
    # Fallback to URL if local file doesn't exist
    url = 'https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBMDeveloperSkillsNetwork-DV0101EN-SkillsNetwork/Data%20Files/Historical_Wildfires.csv'
    df = pd.read_csv(url)
    print("Loaded data from URL.")

# Extract year and month from the date column
df['Date'] = pd.to_datetime(df['Date'])
df['Month'] = df['Date'].dt.month_name() # Names of the months
df['Year'] = df['Date'].dt.year

# --- LAYOUT SECTION ---
app.layout = html.Div(children=[
    # TASK 2.1: Add the Title to the Dashboard
    html.H1('Australia Wildfire Dashboard', 
            style={'textAlign': 'center', 'color': '#503D36', 'font-size': 26}),
    
    # Outer division starts
    html.Div([
        # First inner division for inputs
        html.Div([
            # TASK 2.2: Add the radio items and a dropdown
            html.Div([
                html.H2('Select Region:', style={'margin-right': '2em'}),
                dcc.RadioItems([
                    {"label": "New South Wales", "value": "NSW"},
                    {"label": "Northern Territory", "value": "NT"},
                    {"label": "Queensland", "value": "QL"},
                    {"label": "South Australia", "value": "SA"},
                    {"label": "Tasmania", "value": "TA"},
                    {"label": "Victoria", "value": "VI"},
                    {"label": "Western Australia", "value": "WA"}
                ], value="NSW", id='region', inline=True),
            ]),
            
            html.Div([
                html.H2('Select Year:', style={'margin-right': '2em'}),
                dcc.Dropdown(
                    options=[{'label': str(year), 'value': year} for year in sorted(df.Year.unique())],
                    value=2005, 
                    id='year'
                )
            ]),
        ]),
        
        # TASK 2.3: Second Inner division for output graphs
        html.Div([
            html.Div([], id='plot1'),
            html.Div([], id='plot2')
        ], style={'display': 'flex', 'flex-direction': 'row'}) 
    ])
])

# --- CALLBACK SECTION ---
# TASK 2.4: Add the Output and input components
@app.callback(
    [Output(component_id='plot1', component_property='children'),
     Output(component_id='plot2', component_property='children')],
    [Input(component_id='region', component_property='value'),
     Input(component_id='year', component_property='value')]
)
# TASK 2.5: Add the callback function
def reg_year_display(input_region, input_year):
    # Filter data based on region and year
    region_data = df[df['Region'] == input_region]
    y_r_data = region_data[region_data['Year'] == input_year]
    
    # Plot one - Monthly Average Estimated Fire Area (Pie Chart)
    est_data = y_r_data.groupby('Month')['Estimated_fire_area'].mean().reset_index()
    fig1 = px.pie(est_data, values='Estimated_fire_area', names='Month', 
                  title="{} : Monthly Average Estimated Fire Area in year {}".format(input_region, input_year))
    
    # Plot two - Monthly Average Count of Pixels (Bar Chart)
    veg_data = y_r_data.groupby('Month')['Count'].mean().reset_index()
    fig2 = px.bar(veg_data, x='Month', y='Count', 
                  title='{} : Average Count of Pixels for Presumed Vegetation Fires in year {}'.format(input_region, input_year))
    
    return [dcc.Graph(figure=fig1), 
            dcc.Graph(figure=fig2)]

# Run the app
if __name__ == '__main__':
    app.run(debug=True)